# TextBox Dataset > 2023-04-22 9:19am
https://universe.roboflow.com/fyp-all-datasets-q6yel/textbox-dataset

Provided by a Roboflow user
License: CC BY 4.0

