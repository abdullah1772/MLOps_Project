# Feedback > 2022-10-22 8:20pm
https://universe.roboflow.com/object-detection/feedback

Provided by Roboflow
License: CC BY 4.0

FYP Dataset Hotel Feedback Forms